﻿using RestauranteDAO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductoBL
{
    public class ProductoBL
    {
        public int InsertarProducto(Articulo articulo)
        {
            var Articulos = new List<Articulo>();
            Articulos.Add(articulo);
            //UpdateDatabase()
            return articulo.Id;
        }
        public bool Edit(Articulo articulo)
        {
            try
            {
                var articulos = new List<Articulo>();
                var r = ConsultarArticulo(articulo.Id, articulos);
                r.Nombre = articulo.Nombre;
                r.Id = articulo.Id;
                r.Descripcion = articulo.Descripcion;
                r.Precio = articulo.Precio;
                r.Imagen = articulo.Imagen;
                r.CategoriaId = articulo.CategoriaId;
                return true;
            }
            catch (Exception err)
            {
                return false;
            }


        }
        public bool Eliminar(int Id)
        {
            try
            {
                var articulos = new List<Articulo>();
                var r = ConsultarArticulo(Id, articulos);
                articulos.Remove(r);
                return true;
            }
            catch (Exception err)
            {
                return false;
            }
        }

        public IEnumerable<Articulo> ConsultarArticulos(string nombre)
        {
            var articulos = new List<Articulo>();
            var tmpList = new List<Articulo>();
            foreach (var r in articulos)
            {
                if (r.Nombre.Contains(nombre.ToLower()))
                {
                    tmpList.Add(r);
                }
            }
            return tmpList;
        }
        public Articulo ConsultarArticulo(int id, List<Articulo> context = null)
        {                                     //if      //else
            var articulos = context != null ? context : new List<Articulo>();
            var articulo = new Articulo();
            foreach (var r in articulos)
            {
                if (r.Id == id)
                {
                    articulo = r;
                    break;
                }

            }
            return articulo;
        }
    }
}
